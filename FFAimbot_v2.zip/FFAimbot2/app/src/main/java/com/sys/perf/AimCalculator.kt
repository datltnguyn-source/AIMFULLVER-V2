package com.sys.perf

import kotlin.math.*
import kotlin.random.Random

/**
 * Builds a smooth, humanized gesture path from crosshair (fx,fy) to target (tx,ty).
 *
 * Humanize levels:
 *   0 = raw straight line, fastest
 *   1 = slight Bézier arc, tiny timing jitter
 *   2 = moderate arc + Gaussian noise (default — passes most human-motion checks)
 *   3 = heavy arc + noise + variable step timing (most human-looking)
 */
object AimCalculator {

    private val rng = Random(System.nanoTime())

    private val noiseTable  = floatArrayOf(0f,  1.2f, 2.8f, 5.0f)   // σ px per step
    private val timingTable = longArrayOf( 0L,  2L,   5L,   9L  )   // max extra ms/step
    private val arcTable    = floatArrayOf(0f,  0.08f,0.18f,0.30f)  // control-point scatter

    data class StepPoint(val x: Float, val y: Float, val durationMs: Long)
    data class AimPath(val steps: List<StepPoint>, val totalDist: Float)

    fun buildPath(
        fx: Float, fy: Float,
        tx: Float, ty: Float,
        sens: Float
    ): AimPath {
        val hL    = ConfigManager.humanizeLevel.get().coerceIn(0, 3)
        val noise = noiseTable[hL]
        val timing= timingTable[hL]
        val arc   = arcTable[hL]

        val dx = (tx - fx) * sens
        val dy = (ty - fy) * sens
        val dist = sqrt(dx * dx + dy * dy)

        // Step count scales with distance; more steps → smoother but slower
        val steps = (dist / 14f).roundToInt().coerceIn(3, 24)

        // Quadratic Bézier control point — perturbed perpendicular to the path
        val perpX = -dy; val perpY = dx
        val arcMag = arc * dist
        val cpX = fx + dx * 0.5f + perpX * arcMag * (rng.nextFloat() * 2f - 1f)
        val cpY = fy + dy * 0.5f + perpY * arcMag * (rng.nextFloat() * 2f - 1f)

        val pts = ArrayList<StepPoint>(steps)
        for (i in 1..steps) {
            val t  = i.toFloat() / steps
            val mt = 1f - t
            // Quadratic Bézier
            val bx = mt * mt * fx + 2f * mt * t * cpX + t * t * (fx + dx)
            val by = mt * mt * fy + 2f * mt * t * cpY + t * t * (fy + dy)
            // Gaussian noise for organic micro-jitter
            val nx = if (noise > 0f) gauss(noise) else 0f
            val ny = if (noise > 0f) gauss(noise * 0.6f) else 0f
            // Variable inter-step delay
            val ms = 7L + if (timing > 0L) (rng.nextLong() % timing).let { if (it < 0) -it else it } else 0L
            pts.add(StepPoint(bx + nx, by + ny, ms))
        }

        return AimPath(pts, dist)
    }

    fun shouldAim(cx: Float, cy: Float, tx: Float, ty: Float): Boolean {
        val dx = tx - cx; val dy = ty - cy
        return sqrt(dx * dx + dy * dy) > ConfigManager.lockThreshold.get()
    }

    private fun gauss(sigma: Float): Float {
        val u1 = rng.nextDouble().coerceAtLeast(1e-10)
        val u2 = rng.nextDouble()
        return (sqrt(-2.0 * ln(u1)) * cos(2.0 * PI * u2) * sigma).toFloat()
    }

    private fun Long.let(block: (Long) -> Long): Long = block(this)
}
