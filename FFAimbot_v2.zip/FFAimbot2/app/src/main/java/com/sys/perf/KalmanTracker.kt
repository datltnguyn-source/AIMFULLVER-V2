package com.sys.perf

import org.opencv.core.*
import org.opencv.video.KalmanFilter

/**
 * Constant-velocity Kalman filter for target position smoothing + prediction.
 * State vector: [x, y, vx, vy]  Measurement: [x, y]
 * No android.graphics.PointF dependency — uses own FPoint data class.
 */
class KalmanTracker {

    data class FPoint(val x: Float, val y: Float)

    private val kf          = KalmanFilter(4, 2, 0, CvType.CV_32F)
    private val measurement = Mat.zeros(2, 1, CvType.CV_32F)
    private var initialized = false

    var lastX = 0f; var lastY = 0f
    var velX  = 0f; var velY  = 0f

    init {
        // Transition: x' = x + vx,  y' = y + vy
        val T = Mat.eye(4, 4, CvType.CV_32F)
        T.put(0, 2, 1.0); T.put(1, 3, 1.0)
        kf.set_transitionMatrix(T)

        // Measurement: observe x and y only
        val H = Mat.zeros(2, 4, CvType.CV_32F)
        H.put(0, 0, 1.0); H.put(1, 1, 1.0)
        kf.set_measurementMatrix(H)

        // Noise covariances — tuned for ~60 fps screen capture
        Core.setIdentity(kf.get_processNoiseCov(),     Scalar(4e-3))
        Core.setIdentity(kf.get_measurementNoiseCov(), Scalar(1e-2))
        Core.setIdentity(kf.get_errorCovPost(),        Scalar(1.0))
    }

    fun update(x: Float, y: Float): FPoint {
        if (!initialized) {
            kf.get_statePost().put(0, 0, x.toDouble())
            kf.get_statePost().put(1, 0, y.toDouble())
            kf.get_statePost().put(2, 0, 0.0)
            kf.get_statePost().put(3, 0, 0.0)
            initialized = true
        }
        measurement.put(0, 0, x.toDouble())
        measurement.put(1, 0, y.toDouble())
        kf.predict()
        val corrected = kf.correct(measurement)
        val cx = corrected.get(0, 0)[0].toFloat()
        val cy = corrected.get(1, 0)[0].toFloat()
        velX = cx - lastX; velY = cy - lastY
        lastX = cx;        lastY = cy
        return FPoint(cx, cy)
    }

    /** Linear extrapolation using the filtered velocity. */
    fun predictAhead(frames: Int) = FPoint(lastX + velX * frames, lastY + velY * frames)

    fun reset() {
        initialized = false
        velX = 0f; velY = 0f
        lastX = 0f; lastY = 0f
    }
}
