package com.sys.perf

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.atomic.AtomicBoolean

class AimbotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: AimbotAccessibilityService? = null
    }

    private val dispatching = AtomicBoolean(false)
    private val uiHandler   = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    /**
     * Inject the multi-step gesture path produced by AimCalculator.
     * Uses a single StrokeDescription with a Path through all step points,
     * total duration = sum of per-step delays.
     * Re-entrant calls during dispatch are silently dropped.
     */
    fun performAim(aimPath: AimCalculator.AimPath) {
        if (!dispatching.compareAndSet(false, true)) return
        val steps = aimPath.steps
        if (steps.isEmpty()) { dispatching.set(false); return }

        val gPath = Path()
        gPath.moveTo(steps.first().x, steps.first().y)
        var totalMs = 0L
        for (s in steps) {
            gPath.lineTo(s.x, s.y)
            totalMs += s.durationMs
        }
        val duration = totalMs.coerceAtLeast(16L)

        val stroke  = GestureDescription.StrokeDescription(gPath, 0L, duration, false)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { dispatching.set(false) }
            override fun onCancelled(g: GestureDescription?) { dispatching.set(false) }
        }, uiHandler)
    }
}
