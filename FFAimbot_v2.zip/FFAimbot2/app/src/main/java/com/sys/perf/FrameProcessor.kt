package com.sys.perf

import android.graphics.Bitmap
import android.os.Handler
import android.os.HandlerThread
import org.opencv.android.Utils
import org.opencv.core.Mat
import java.util.concurrent.atomic.AtomicReference

/**
 * Runs the detection + aim pipeline on a dedicated background thread.
 * Frames are submitted from the capture thread; only the latest frame
 * is processed — older ones are dropped to avoid queue build-up.
 * Loop period: 8 ms (~125 fps ceiling, limited in practice by capture rate).
 */
class FrameProcessor(
    private val screenW: Int,
    private val screenH: Int,
    private val onTarget: (AimCalculator.AimPath?) -> Unit
) {
    private val thread  = HandlerThread("ProcThread").also { it.start() }
    private val handler = Handler(thread.looper)
    private val pending = AtomicReference<Bitmap?>(null)

    private val lock = TargetLock()
    private val mat  = Mat()

    private val loop = object : Runnable {
        override fun run() {
            val bmp = pending.getAndSet(null)
            if (bmp != null && ConfigManager.isActive.get()) {
                processFrame(bmp)
                bmp.recycle()
            }
            handler.postDelayed(this, 8L)
        }
    }

    init { handler.post(loop) }

    fun submitFrame(bmp: Bitmap) {
        // Atomically swap; recycle the frame we're discarding
        pending.getAndSet(bmp)?.recycle()
    }

    private fun processFrame(bmp: Bitmap) {
        Utils.bitmapToMat(bmp, mat)
        val fov  = ConfigManager.fovRadius.get()
        val dets = EnemyDetector.detect(mat, screenW, screenH, fov)
        val cx   = screenW / 2; val cy = screenH / 2
        val pred = lock.update(dets, cx, cy, fov)

        if (pred == null) { onTarget(null); return }
        if (!AimCalculator.shouldAim(cx.toFloat(), cy.toFloat(), pred.x, pred.y)) {
            onTarget(null); return
        }
        onTarget(
            AimCalculator.buildPath(
                cx.toFloat(), cy.toFloat(),
                pred.x, pred.y,
                ConfigManager.sensitivity.get()
            )
        )
    }

    fun hasLock() = lock.hasLock()

    fun shutdown() {
        handler.removeCallbacksAndMessages(null)
        thread.quitSafely()
        mat.release()
    }
}
