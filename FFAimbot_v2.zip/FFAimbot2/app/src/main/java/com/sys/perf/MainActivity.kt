package com.sys.perf

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var mpm: MediaProjectionManager
    private val REQ_PROJ = 1001
    private val REQ_OVL  = 1002
    private lateinit var txtStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ConfigManager.init(this)
        setContentView(R.layout.activity_main)

        mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val btnStart    = findViewById<Button>(R.id.btnStart)
        val switchAim   = findViewById<Switch>(R.id.switchAimbot)
        val seekSens    = findViewById<SeekBar>(R.id.seekSens)
        val seekFov     = findViewById<SeekBar>(R.id.seekFov)
        val seekPred    = findViewById<SeekBar>(R.id.seekPred)
        val seekHuman   = findViewById<SeekBar>(R.id.seekHuman)
        val spinnerBone = findViewById<Spinner>(R.id.spinnerBone)
        val fovPreview  = findViewById<FovPreviewView>(R.id.fovPreview)
        val txtFovVal   = findViewById<TextView>(R.id.txtFovValue)
        txtStatus       = findViewById(R.id.txtStatus)

        // Bone spinner: HEAD / NECK / BODY
        spinnerBone.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            arrayOf("HEAD", "NECK", "BODY")
        )
        val boneIdx = when (ConfigManager.targetBone.get()) {
            ConfigManager.Bone.HEAD -> 0
            ConfigManager.Bone.NECK -> 1
            else                    -> 2
        }
        spinnerBone.setSelection(boneIdx)
        spinnerBone.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, i: Int, id: Long) {
                ConfigManager.targetBone.set(
                    when (i) { 0 -> ConfigManager.Bone.HEAD; 1 -> ConfigManager.Bone.NECK; else -> ConfigManager.Bone.BODY }
                )
                ConfigManager.save()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Sensitivity  0–100 → 0.0–1.0
        seekSens.max      = 100
        seekSens.progress = (ConfigManager.sensitivity.get() * 100).toInt()
        seekSens.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                ConfigManager.sensitivity.set(p / 100f); ConfigManager.save()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // FOV  0–500 px
        seekFov.max      = 500
        seekFov.progress = ConfigManager.fovRadius.get()
        txtFovVal.text   = "FOV RADIUS: ${ConfigManager.fovRadius.get()} px"
        fovPreview.setRadiusDp(ConfigManager.fovRadius.get() / resources.displayMetrics.density)
        seekFov.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                ConfigManager.fovRadius.set(p)
                txtFovVal.text = "FOV RADIUS: $p px"
                fovPreview.setRadiusDp(p / resources.displayMetrics.density)
                ConfigManager.save()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // Prediction latency  0–120 ms
        seekPred.max      = 120
        seekPred.progress = ConfigManager.predictionMs.get()
        seekPred.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                ConfigManager.predictionMs.set(p); ConfigManager.save()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // Humanize  0–3
        seekHuman.max      = 3
        seekHuman.progress = ConfigManager.humanizeLevel.get()
        seekHuman.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                ConfigManager.humanizeLevel.set(p); ConfigManager.save()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        switchAim.setOnCheckedChangeListener { _, v ->
            if (ScreenCaptureService.instance == null) {
                switchAim.isChecked = false
                txtStatus.text      = "tap START CAPTURE first"
                return@setOnCheckedChangeListener
            }
            ScreenCaptureService.instance?.setActive(v)
            txtStatus.text = if (v) "AIMBOT ACTIVE" else "AIMBOT PAUSED"
        }

        btnStart.setOnClickListener { checkPerms() }
    }

    private fun checkPerms() {
        if (!Settings.canDrawOverlays(this)) {
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                REQ_OVL
            )
            return
        }
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJ)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_OVL  -> if (Settings.canDrawOverlays(this)) checkPerms()
            REQ_PROJ -> if (resultCode == Activity.RESULT_OK && data != null) {
                startForegroundService(
                    Intent(this, ScreenCaptureService::class.java)
                        .putExtra("resultCode", resultCode)
                        .putExtra("data", data)
                )
                txtStatus.text = "capture started — enable Accessibility"
            }
        }
    }

    override fun onStop() { super.onStop(); ConfigManager.save() }
}
