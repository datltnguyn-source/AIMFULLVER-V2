package com.sys.perf

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import org.opencv.android.OpenCVLoader

class ScreenCaptureService : Service() {

    companion object {
        @Volatile var instance: ScreenCaptureService? = null
        private const val CH  = "aim_bg"
        private const val NID = 7
    }

    private var projection: MediaProjection? = null
    private var vDisplay:   VirtualDisplay?  = null
    private var reader:     ImageReader?     = null
    private var proc:       FrameProcessor?  = null
    private var overlay:    OverlayView?     = null
    private var cvOk = false
    private var sw = 0; private var sh = 0

    private lateinit var capThread:  HandlerThread
    private lateinit var capHandler: Handler

    override fun onCreate() {
        super.onCreate()
        instance = this
        cvOk     = OpenCVLoader.initLocal()
        if (!cvOk) { Log.e("SCS", "OpenCV load failed"); stopSelf(); return }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = wm.currentWindowMetrics
        sw = dm.bounds.width(); sh = dm.bounds.height()

        capThread  = HandlerThread("CapThread").also { it.start() }
        capHandler = Handler(capThread.looper)

        createNotificationChannel()
        startForeground(NID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!cvOk) return START_NOT_STICKY

        val resultCode = intent?.getIntExtra("resultCode", -1) ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(resultCode, data)

        proc = FrameProcessor(sw, sh) { path ->
            if (path != null) AimbotAccessibilityService.instance?.performAim(path)
            overlay?.let { v ->
                v.locked    = proc?.hasLock() == true
                v.fovRadius = ConfigManager.fovRadius.get().toFloat()
                v.postInvalidate()
            }
        }

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = OverlayView.attach(this, wm)

        reader = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 3)
        vDisplay = projection?.createVirtualDisplay(
            "ff_cap", sw, sh,
            resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, capHandler
        )

        reader?.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (!ConfigManager.isActive.get()) return@setOnImageAvailableListener
                val plane = img.planes[0]
                val ps    = plane.pixelStride
                val rs    = plane.rowStride
                val bmpW  = sw + (rs - ps * sw) / ps
                val full  = Bitmap.createBitmap(bmpW, sh, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(plane.buffer)
                val crop  = Bitmap.createBitmap(full, 0, 0, sw, sh)
                full.recycle()
                proc?.submitFrame(crop)
            } finally {
                img.close()
            }
        }, capHandler)

        return START_STICKY
    }

    fun setActive(v: Boolean) {
        ConfigManager.isActive.set(v)
        overlay?.postInvalidate()
    }

    override fun onDestroy() {
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        proc?.shutdown()
        capThread.quitSafely()
        overlay?.let { v ->
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v)
        }
        instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CH, "Background", NotificationManager.IMPORTANCE_MIN)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(ch)
    }

    private fun buildNotification() = NotificationCompat.Builder(this, CH)
        .setContentTitle("System Tools")
        .setContentText("Active")
        .setSmallIcon(android.R.drawable.ic_menu_manage)
        .setPriority(NotificationCompat.PRIORITY_MIN)
        .build()
}
