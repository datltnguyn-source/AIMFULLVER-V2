package com.sys.perf

import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min

/**
 * Free Fire MAX skeleton layout (portrait 1080×1920, typical render distance 10-80 m)
 * ─────────────────────────────────────────────────────────────────────────────────────
 * The game renders a name-tag bar (red HP strip) above the character and a green
 * silhouette outline around the body mesh.  From those two visual anchors we
 * reconstruct a 5-bone skeleton in screen space:
 *
 *   HEAD   = top of bounding rect + headFraction × height   (skull crown)
 *   NECK   = top of bounding rect + neckFraction × height   (chin/throat)
 *   BODY   = top of bounding rect + bodyFraction × height   (chest centre)
 *   BELLY  = top of bounding rect + bellyFraction × height  (solar plexus)
 *   LEGS   = top of bounding rect + legsFraction × height   (upper legs)
 *
 * Fractions are calibrated against the game's character proportions:
 *   head  ≈ 10 % from top  (crown)
 *   neck  ≈ 20 %
 *   body  ≈ 38 %           (chest — largest hitbox)
 *   belly ≈ 55 %
 *   legs  ≈ 72 %
 *
 * When a name bar (HP) is detected above the blob, we use it to anchor the top
 * of the character more precisely: top-of-character = bottom-of-name-bar + gap.
 *
 * Detection pipeline
 * ──────────────────
 * 1. Crop the FOV circle region of interest (ROI).
 * 2. Convert BGRA → BGR → HSV.
 * 3. Mask red hue bands (HP bar + outline accents).
 * 4. Mask green-teal hue band (body silhouette / outline shader).
 * 5. Mask near-white hue band (name text).
 * 6. Morphological open + dilate to clean each mask.
 * 7. Find external contours on (red ∪ green) combined mask.
 * 8. Per contour: compute area, aspect, nzRatio per sub-mask.
 * 9. Score: isBar (HP) + isBlob (body) + hasName → need ≥ 2 cues.
 * 10. Reconstruct skeleton in absolute screen coords.
 * 11. Return Detection list sorted by distance from screen centre.
 */
object EnemyDetector {

    // Skeleton fractions (top of bounding box = 0.0, bottom = 1.0)
    private const val F_HEAD  = 0.10f
    private const val F_NECK  = 0.22f
    private const val F_BODY  = 0.38f
    private const val F_BELLY = 0.55f
    private const val F_LEGS  = 0.72f

    // HSV colour ranges ─────────────────────────────────────────────
    // Red HP bar / red outline accent  (wraps 0° and 360°)
    private val redLo1 = Scalar(0.0,  130.0, 120.0)
    private val redHi1 = Scalar(10.0, 255.0, 255.0)
    private val redLo2 = Scalar(165.0,130.0, 120.0)
    private val redHi2 = Scalar(180.0,255.0, 255.0)

    // Green-teal body outline shader used by FF MAX
    private val outLo  = Scalar(32.0,  70.0, 140.0)
    private val outHi  = Scalar(88.0, 255.0, 255.0)

    // Near-white name text (very low saturation, high value)
    private val nameLo = Scalar(0.0,   0.0,  210.0)
    private val nameHi = Scalar(180.0, 30.0, 255.0)

    // Reusable Mats (single-threaded caller — FrameProcessor's HandlerThread)
    private val bgr       = Mat(); private val hsv      = Mat(); private val roiMat   = Mat()
    private val mRed1     = Mat(); private val mRed2    = Mat(); private val mRed      = Mat()
    private val mOutline  = Mat(); private val mName    = Mat(); private val mCombined = Mat()
    private val hierarchy = Mat()

    // Morphological kernels
    private val kOpen3 = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0))
    private val kDil5  = Imgproc.getStructuringElement(Imgproc.MORPH_RECT,    Size(7.0, 3.0))
    private val kOpen5 = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(5.0, 5.0))
    private val kDil3  = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0))

    fun detect(frame: Mat, screenW: Int, screenH: Int, fovRadius: Int): List<Detection> {
        val cx = screenW / 2; val cy = screenH / 2; val r = fovRadius
        val x0 = max(0, cx - r); val y0 = max(0, cy - r)
        val x1 = min(screenW, cx + r); val y1 = min(screenH, cy + r)
        val roiW = x1 - x0; val roiH = y1 - y0
        if (roiW <= 0 || roiH <= 0) return emptyList()

        frame.submat(Rect(x0, y0, roiW, roiH)).copyTo(roiMat)
        Imgproc.cvtColor(roiMat, bgr, Imgproc.COLOR_BGRA2BGR)
        Imgproc.cvtColor(bgr, hsv, Imgproc.COLOR_BGR2HSV)

        // Red mask (HP bar + red accents)
        Core.inRange(hsv, redLo1, redHi1, mRed1)
        Core.inRange(hsv, redLo2, redHi2, mRed2)
        Core.add(mRed1, mRed2, mRed)
        Imgproc.morphologyEx(mRed, mRed, Imgproc.MORPH_OPEN, kOpen3)
        Imgproc.dilate(mRed, mRed, kDil5)

        // Outline mask (body silhouette)
        Core.inRange(hsv, outLo, outHi, mOutline)
        Imgproc.morphologyEx(mOutline, mOutline, Imgproc.MORPH_OPEN, kOpen5)
        Imgproc.dilate(mOutline, mOutline, kDil3)

        // Name text mask
        Core.inRange(hsv, nameLo, nameHi, mName)

        // Combined for contour finding
        Core.add(mRed, mOutline, mCombined)

        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(
            mCombined, contours, hierarchy,
            Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE
        )

        val results = ArrayList<Detection>()

        for (c in contours) {
            val area = Imgproc.contourArea(c)
            if (area < 35.0 || area > 20000.0) continue

            val rect = Imgproc.boundingRect(c)
            if (rect.width < 6 || rect.height < 4) continue

            val redR = nzRatio(mRed, rect)
            val outR = nzRatio(mOutline, rect)
            val ar   = rect.width.toFloat() / max(rect.height, 1)
            val arV  = rect.height.toFloat() / max(rect.width, 1)

            // HP bar: wide, short, high red density
            val isBar  = redR > 0.22f && ar >= 1.8f && rect.width <= 340 && rect.height <= 26
            // Body blob: taller-or-square, has outline pixels
            val isBlob = outR > 0.12f && arV >= 0.35f
            if (!isBar && !isBlob) continue

            val hasName = nameAbove(mName, rect)
            val cues = (if (isBar) 1 else 0) + (if (isBlob) 1 else 0) + (if (hasName) 1 else 0)
            if (cues < 2) continue

            // Absolute screen coordinates of bounding-rect top-left
            val absLeft = x0 + rect.x
            val absTop  = y0 + rect.y
            val h       = rect.height

            // ── Skeleton reconstruction ──────────────────────────────────────
            // If we see an HP bar, the character top is just below it.
            // HP bar typically sits 2–6 px above the head crown.
            val characterTopAbs: Int
            val characterH: Int
            if (isBar && !isBlob) {
                // pure bar detection: estimate body height from bar width
                // FF bar width ≈ 55 % of body bounding width; body height ≈ 2.8× bar width
                val estBodyH = (rect.width * 2.8f).toInt().coerceIn(40, 320)
                characterTopAbs = absTop + rect.height + 2   // below bar
                characterH      = estBodyH
            } else {
                characterTopAbs = absTop
                characterH      = h
            }

            val headX  = absLeft + rect.width / 2
            val headY  = characterTopAbs + (characterH * F_HEAD).toInt()
            val neckY  = characterTopAbs + (characterH * F_NECK).toInt()
            val bodyY  = characterTopAbs + (characterH * F_BODY).toInt()

            // Edge filter — ignore detections glued to screen edges (UI elements)
            val edgeMargin = 32
            if (absLeft < edgeMargin || absTop < edgeMargin ||
                absLeft + rect.width  > screenW - edgeMargin ||
                absTop  + rect.height > screenH - edgeMargin) continue

            val conf = 0.33f * (if (isBar) 1f else 0f) +
                       0.33f * (if (isBlob) 1f else 0f) +
                       0.34f * (if (hasName) 1f else 0f)

            results.add(
                Detection(
                    x          = headX,
                    y          = headY,          // primary aim point (overridden by TargetLock based on Bone)
                    headX      = headX,
                    headY      = headY,
                    neckY      = neckY,
                    bodyY      = bodyY,
                    area       = area,
                    confidence = conf
                )
            )
        }

        // Sort closest-to-crosshair first
        results.sortBy { d ->
            val dx = (d.headX - cx).toFloat(); val dy = (d.headY - cy).toFloat()
            dx * dx + dy * dy
        }
        return results
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun nzRatio(mask: Mat, rect: Rect): Float {
        val sr = safeRect(mask, rect) ?: return 0f
        val sub = mask.submat(sr)
        val nz  = Core.countNonZero(sub)
        sub.release()
        return nz.toFloat() / max(sr.area().toInt(), 1)
    }

    /** Check for white name-text pixels in the zone above the detection rect */
    private fun nameAbove(mask: Mat, rect: Rect): Boolean {
        val lh = (rect.height * 2.5f).toInt().coerceAtLeast(14)
        val ny = (rect.y - lh).coerceAtLeast(0)
        val nh = rect.y - ny
        if (nh <= 0) return false
        val sr = safeRect(mask, Rect(rect.x, ny, rect.width, nh)) ?: return false
        val sub = mask.submat(sr)
        val nz  = Core.countNonZero(sub)
        sub.release()
        return nz > 10
    }

    private fun safeRect(mat: Mat, rect: Rect): Rect? {
        val x  = rect.x.coerceAtLeast(0)
        val y  = rect.y.coerceAtLeast(0)
        val x2 = (rect.x + rect.width).coerceAtMost(mat.width())
        val y2 = (rect.y + rect.height).coerceAtMost(mat.height())
        return if (x2 <= x || y2 <= y) null else Rect(x, y, x2 - x, y2 - y)
    }
}
