package com.sys.perf

import kotlin.math.sqrt

/**
 * Maintains a lock on the best enemy target across frames.
 * Selects the aim point from the requested bone (HEAD / NECK / BODY).
 * Uses Kalman smoothing + velocity-based prediction for the locked target.
 */
class TargetLock {

    private var locked:   Detection? = null
    private var lockAge:  Int = 0
    private val MAX_AGE         = 10         // frames before lock expires
    private val SWITCH_HYSTERESIS = 70f      // px advantage needed to steal lock

    private val kalman = KalmanTracker()
    private var predX  = 0f
    private var predY  = 0f

    /**
     * @return predicted aim point (screen coords) for this frame, or null if no lock.
     */
    fun update(
        detections: List<Detection>,
        screenCx: Int,
        screenCy: Int,
        fovRadius: Int
    ): KalmanTracker.FPoint? {

        if (detections.isEmpty()) {
            lockAge++
            if (lockAge > MAX_AGE) { locked = null; kalman.reset() }
            return if (locked != null) KalmanTracker.FPoint(predX, predY) else null
        }

        // Pick best candidate
        val current = locked
        val best: Detection? = if (current == null) {
            // No existing lock → closest to crosshair with best confidence score
            detections.minByOrNull { score(it, screenCx, screenCy) }
        } else {
            val curDist = dist(current.headX, boneY(current), screenCx, screenCy)
            val candidate = detections.minByOrNull { score(it, screenCx, screenCy) }!!
            val candDist  = dist(candidate.headX, boneY(candidate), screenCx, screenCy)
            // Hysteresis: only switch if candidate is significantly closer
            if (curDist - candDist > SWITCH_HYSTERESIS) candidate
            else {
                // Stay on locked target — find closest detection to it
                detections.minByOrNull {
                    dist(it.headX, boneY(it), current.headX, boneY(current))
                }
            }
        }

        if (best == null) return null
        // Reject targets outside FOV
        if (dist(best.headX, boneY(best), screenCx, screenCy) > fovRadius) return null

        locked  = best
        lockAge = 0

        // Kalman update on bone-specific Y
        kalman.update(best.headX.toFloat(), boneY(best).toFloat())

        // Predict ahead by predictionMs / 16 ms per frame ≈ frames
        val frames = (ConfigManager.predictionMs.get() / 16).coerceAtLeast(1)
        val pred   = kalman.predictAhead(frames)
        predX = pred.x
        predY = pred.y
        return KalmanTracker.FPoint(predX, predY)
    }

    fun hasLock() = locked != null && lockAge <= MAX_AGE

    // ── Bone selection ───────────────────────────────────────────────────────

    private fun boneY(d: Detection): Int = when (ConfigManager.targetBone.get()) {
        ConfigManager.Bone.HEAD -> d.headY
        ConfigManager.Bone.NECK -> d.neckY
        ConfigManager.Bone.BODY -> d.bodyY
        else                    -> d.headY
    }

    // ── Scoring: lower = better ──────────────────────────────────────────────

    private fun score(d: Detection, cx: Int, cy: Int): Float {
        val d2 = dist(d.headX, boneY(d), cx, cy)
        return d2 / (d.confidence * 120f + 1f)
    }

    private fun dist(x1: Int, y1: Int, x2: Int, y2: Int): Float {
        val dx = (x2 - x1).toFloat(); val dy = (y2 - y1).toFloat()
        return sqrt(dx * dx + dy * dy)
    }
}
