package com.sys.perf

import android.content.Context
import android.content.SharedPreferences
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

object ConfigManager {
    private lateinit var prefs: SharedPreferences

    val isActive       = AtomicBoolean(false)
    val fovRadius      = AtomicInteger(220)
    val sensitivity    = AtomicReference(0.55f)
    val predictionMs   = AtomicInteger(48)
    val humanizeLevel  = AtomicInteger(2)
    val lockThreshold  = AtomicInteger(10)
    val targetBone     = AtomicReference(Bone.HEAD)
    val smoothFactor   = AtomicReference(0.72f)

    // HEAD  = centre of bounding-box top + headOff  (crown of skull)
    // NECK  = crown + ~18 % of box height            (neck/chin line)
    // BODY  = vertical midpoint of bounding box      (chest)
    enum class Bone { HEAD, NECK, BODY }

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("cfg2", Context.MODE_PRIVATE)
        fovRadius.set(prefs.getInt("fov",   220))
        sensitivity.set(prefs.getFloat("sens", 0.55f))
        predictionMs.set(prefs.getInt("pred",  48))
        humanizeLevel.set(prefs.getInt("hum",   2))
        smoothFactor.set(prefs.getFloat("smooth", 0.72f))
        targetBone.set(Bone.valueOf(prefs.getString("bone", "HEAD") ?: "HEAD"))
    }

    fun save() {
        prefs.edit()
            .putInt("fov",    fovRadius.get())
            .putFloat("sens", sensitivity.get())
            .putInt("pred",   predictionMs.get())
            .putInt("hum",    humanizeLevel.get())
            .putFloat("smooth", smoothFactor.get())
            .putString("bone", targetBone.get().name)
            .apply()
    }
}
