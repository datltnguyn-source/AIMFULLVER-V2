# FF Aimbot — screen-capture + accessibility gesture injection

## Architecture

```
MediaProjection → ImageReader → FrameProcessor (8ms loop)
                                     │
                              EnemyDetector (OpenCV HSV)
                                     │
                              TargetLock + KalmanTracker
                                     │
                              AimCalculator (Bézier path)
                                     │
                        AimbotAccessibilityService.dispatchGesture()
```

## Skeleton targeting

| Bone | Fraction from box top | Description |
|------|-----------------------|-------------|
| HEAD | 10 % | skull crown — highest headshot hit priority |
| NECK | 22 % | chin/throat |
| BODY | 38 % | chest centre — largest hitbox |

## Build on GitHub (zero local setup)

1. Push this repo to GitHub.
2. Go to **Actions → Build Aimbot APK → Run workflow**.
3. Download `aimbot-debug.apk` from the run artifacts.

## Device setup

1. Install APK (`adb install -r aimbot-debug.apk` or sideload).
2. Grant **Display over other apps** permission.
3. Enable **Touch Enhancer** in Accessibility settings.
4. Open app → tap **START CAPTURE** → allow screen recording.
5. Toggle **AIMBOT ON**.

## Tuning

| Slider | Range | Advice |
|--------|-------|--------|
| Sensitivity | 0–100 | 40–60 is natural for most devices |
| FOV Radius | 0–500 px | 180–260 px covers typical close-range combat |
| Prediction | 0–120 ms | 40–60 ms for fast targets |
| Humanize | 0–3 | 2 passes most anti-cheat motion checks |
| Target Bone | HEAD/NECK/BODY | HEAD for headshots; BODY for reliability |
